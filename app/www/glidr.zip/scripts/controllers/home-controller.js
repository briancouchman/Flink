'use strict';

angular.module('flink').controller('HomeController', function($scope){

  console.log("Initializing Home controller");

});
