'use strict';

angular.module('flink').directive('loginDirective', function(){
  return {
    templateUrl: 'views/tpl/login.tpl.html'
  }
});
