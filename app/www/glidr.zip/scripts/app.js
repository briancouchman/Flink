'use strict';

angular.module('flink', [
  "ngRoute",
  "ngResource",
  "mobile-angular-ui",
])
